@include('frontend.header')

      <div class="container-fluid" style="padding-bottom:5%;">
  <div class="py-5 text-center">
    
    <h2>Checkout form</h2>
     </div>

  <div class="row">
    <div class="col-md-4 order-md-2 mb-4" style="padding: 77px;">
     
      <ul class="list-group mb-3">
        
        <li class="list-group-item d-flex justify-content-between lh-condensed">
          <div>
            <h6 class="my-0">Sub Total</h6>
            <small class="text-muted">Total Person Added (6 No.s)</small>
          </div>
          <span class="text-muted">$8</span>
        </li>

        <li class="list-group-item d-flex justify-content-between lh-condensed">
          <div>
           
            <small class="text-muted">
            <form class="card p-2">
        <div class="input-group">
        
          <input type="text" class="form-control" placeholder="Apply Coupon">
         
            <button type="submit" class="btn btn-secondary">Apply</button>
         
        </div>
      </form>


            </small>
          </div>
         
        </li>



       
       
        <li class="list-group-item d-flex justify-content-between bg-light">
          <div class="text-success">
            <h6 class="my-0">Code Details</h6>
            <small>Discount Amount</small>
          </div>
          <span class="text-success">-$5</span>
        </li>
        <li class="list-group-item d-flex justify-content-between">
          <span>Total (USD)</span>
          <strong>$20</strong>
        </li>
      </ul>

      
    </div>
    <div class="col-md-8 order-md-1">
      <h4 class="mb-3">Billing address</h4>
      <form class="needs-validation" novalidate>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="firstName">Full Name</label>
            <input type="text" class="form-control" id="firstName" placeholder="" value="" >
            
          </div>
          <div class="col-md-6 mb-3">
            <label for="lastName">Billing Name</label>
            <input type="text" class="form-control" id="lastName" placeholder="" value="" >
            
          </div>
        </div>

        <div class="mb-3">
          <label for="email">Phone </label>
          <input type="email" class="form-control" id="email" placeholder="">
         
        </div>

        <div class="mb-3">
          <label for="email">Email <span class="text-muted">(Required)</span></label>
          <input type="email" class="form-control" id="email" placeholder="">
          
        </div>


        <div class="mb-3">
          <label for="email">Driving License Number </label>
          <input type="email" class="form-control" id="email" placeholder="">
          
        </div>


        <div class="mb-3">
          <label for="address">Comments</label>
          <input type="text" class="form-control" id="address" placeholder="" >
          
        </div>


        <div>
            <button class="btn btn-success">Add Member</button>
</div>


     

       
        
         
       

      

     
       
        <style>
table, th, td {
  border:1px solid black;
}
</style>
<body>

<br/><br/>

<table style="width:100%">
  <tr>
    <th style="text-align:center;">#</th>
    <th style="text-align:center;">Name</th>
    <th style="text-align:center;">Phone</th>
    <th style="text-align:center;">Email</th>
    <th style="text-align:center;">Driving License</th>
    <th style="text-align:center;">Edit</th>
    <th style="text-align:center;">Remove Details</th>
  </tr>
  @for($i=1;$i<=6; $i++)
  <tr>
    <td style="text-align:center;"> {{$i}}</td>
    <td style="text-align:center;">Name - {{$i}}</td>
    <td style="text-align:center;">@php $randnum = rand(88888,99999);$randnum2 = rand(88888,99999); @endphp {{$randnum}} {{$randnum2}} </td>
    <td style="text-align:center;">Sample- {{$i}}@gmail.com </td>
    <td style="text-align:center;"><?php $result = uniqid(); echo $result;?></td>
    <td style="text-align:center;"><a href="">Edit</a></td>
<td style="text-align:center;"><a href=""><b style="color:red;">Delete</b></a></td>
 
  </tr>
  @endfor
 
</table>



<br/>
        <hr class="mb-4">
       
      </form>
    </div>
  </div>
  <button class="btn btn-primary btn-lg btn-block" type="submit">Continue to checkout</button>
 
</div>
</div>
    <!-- Main Footer -->
    <footer class="main-footer">
 
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="inner-container clearfix">
                    <div class="copyright-text">
                        <p>© Copyright 2020 All Rights Reserved by <a href="index.html">Expert-Themes</a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer -->

</div>
<!--End pagewrapper-->

<!-- Color Palate / Color Switcher -->
<div class="color-palate">
    <div class="color-trigger">
        <i class="fa fa-cog"></i>
    </div>
    <div class="color-palate-head">
        <h6>Choose Your Demo</h6>
    </div>
    <ul class="box-version option-box"> <li>Full width</li> <li class="box">Boxed</li> </ul>
    <ul class="rtl-version option-box"> <li>LTR Version</li> <li class="rtl">RTL Version</li> </ul>
    <div class="palate-foo">
        <span>You will find much more options for colors and styling in admin panel. This color picker is used only for demonstation purposes.</span>
    </div>
    <a href="#" class="purchase-btn">Purchase now</a>
</div><!-- End Color Switcher -->

<!--Search Popup-->
<div id="search-popup" class="search-popup">
	<div class="close-search theme-btn"><span class="fas fa-window-close"></span></div>
	<div class="popup-inner">
		<div class="overlay-layer"></div>
    	<div class="search-form">
        	<form method="post" action="index.html">
            	<div class="form-group">
                	<fieldset>
                        <input type="search" class="form-control" name="search-input" value="" placeholder="Search Here" required >
                        <input type="submit" value="Search Now!" class="theme-btn">
                    </fieldset>
                </div>
            </form>

            <br>
            <h3>Recent Search Keywords</h3>
            <ul class="recent-searches">
                <li><a href="#">Seo</a></li>
                <li><a href="#">Bussiness</a></li>
                <li><a href="#">Events</a></li>
                <li><a href="#">Digital</a></li>
                <li><a href="#">Conferance</a></li>
            </ul>

        </div>

    </div>
</div>

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-double-up"></span></div>
@include('frontend.script')

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<script>$(function() {
  $('.accordion li').click(function(){
    $(this).toggleClass(' active ');
    $(this).siblings().removeClass(' active '); 
    $('.submenu').stop().slideUp();
    $('.active .submenu').stop().slideDown();
    return false;
  });
});
</script>
</body>
</html>
