<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-double-up"></span></div>
<script src="{{asset('frontend_lib/js/jquery.js')}}"></script>
<script src="{{asset('frontend_lib/js/popper.min.js')}}"></script>
<script src="{{asset('frontend_lib/js/bootstrap.min.js')}}"></script>
<script src="{{asset('frontend_lib/js/jquery-ui.js')}}"></script>
<script src="{{asset('frontend_lib/js/jquery.fancybox.js')}}"></script>
<script src="{{asset('frontend_lib/js/appear.js')}}"></script>
<script src="{{asset('frontend_lib/js/owl.js')}}"></script>
<script src="{{asset('frontend_lib/js/jquery.countdown.js')}}"></script>
<script src="{{asset('frontend_lib/js/wow.js')}}"></script>
<script src="{{asset('frontend_lib/js/script.js')}}"></script>
<!-- Color Setting -->
<script src="{{asset('frontend_lib/js/color-settings.js')}}"></script>